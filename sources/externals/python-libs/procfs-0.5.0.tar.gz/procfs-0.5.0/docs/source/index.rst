procfs
******

A python API for the Linux /proc virtual filesystem.

.. toctree::
    :maxdepth: 2

.. automodule:: procfs
    :members:
    :inherited-members:
    :undoc-members:

 Indices and tables
 ==================

 * :ref:`genindex`
 * :ref:`modindex`
 * :ref:`search`

