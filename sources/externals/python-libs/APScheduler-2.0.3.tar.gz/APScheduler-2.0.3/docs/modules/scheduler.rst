:mod:`apscheduler.scheduler`
============================

.. automodule:: apscheduler.scheduler

Module Contents
---------------

.. autoclass:: Scheduler
    :members:
.. autoexception:: SchedulerAlreadyRunningError
