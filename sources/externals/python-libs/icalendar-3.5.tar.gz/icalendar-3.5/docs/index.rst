
.. include:: ../README.rst

Contents
========

.. toctree::
    :maxdepth: 2

    about
    install
    examples
    RFC 5545 <rfc5545/index>
    changelog
    credits
    license
