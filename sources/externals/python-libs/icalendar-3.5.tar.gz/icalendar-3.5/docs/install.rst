Installing iCalendar
====================

To install the icalendar package, use::

  python setup.py install

If installation is successful, you be able to import the iCalendar
package, like this::

  >>> import icalendar
