Generate Documentation
======================

Requirements
------------

To generate documentation you need to install:

 - Python >= 2.5
 - Sphinx (http://sphinx.pocoo.org/)


Generate html
-------------
::

    $ make html

The command generates html document inside ``build/html`` dir.
