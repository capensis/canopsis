# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, print_function, unicode_literals

from grako._version import __version__  # noqa
from grako.tool import gencode, genmodel, main  # noqa


if __name__ == '__main__':
    main()
