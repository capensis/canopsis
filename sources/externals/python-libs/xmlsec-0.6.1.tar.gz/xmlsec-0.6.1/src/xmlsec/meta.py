version = '0.6.1'
description = 'Python bindings for the XML Security Library.'
