socket_action(sockfd, ev_bitmask) -> Tuple.

Returns result from doing a socket_action() on the curl multi file descriptor
with the given timeout.
