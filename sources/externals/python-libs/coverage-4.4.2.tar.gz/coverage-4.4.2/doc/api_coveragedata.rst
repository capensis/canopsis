.. Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
.. For details: https://bitbucket.org/ned/coveragepy/src/default/NOTICE.txt

.. _api_coveragedata:

The CoverageData class
----------------------

.. :history: 20150802T174800, new doc for 4.0b1

.. versionadded:: 4.0

.. module:: coverage

.. autoclass:: CoverageData
    :members:
    :special-members: __init__
