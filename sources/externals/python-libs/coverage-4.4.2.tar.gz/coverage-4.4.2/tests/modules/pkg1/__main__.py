# Used in the tests for run_python_module
import sys
print("pkg1.__main__: passed %s" % sys.argv[1])
