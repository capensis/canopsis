Please refer to src/RestrictedPython/README.txt.
