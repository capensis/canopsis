# This __init__.py is only here for convenience, for projects that include a
# version of polib as a mercurial sub-repository for example.
#
# This file will NOT be installed when installing polib with pip, setuptools,
# or any other mecanism based on the setup.py file.
